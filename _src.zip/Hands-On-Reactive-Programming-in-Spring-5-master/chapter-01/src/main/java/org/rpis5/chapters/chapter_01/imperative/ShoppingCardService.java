package org.rpis5.chapters.chapter_01.imperative;

import org.rpis5.chapters.chapter_01.commons.Input;
import org.rpis5.chapters.chapter_01.commons.Output;

public interface ShoppingCardService {
    Output calculate(Input value);
}
