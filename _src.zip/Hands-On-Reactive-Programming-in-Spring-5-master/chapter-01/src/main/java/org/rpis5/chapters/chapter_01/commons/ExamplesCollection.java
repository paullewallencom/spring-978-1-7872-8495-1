package org.rpis5.chapters.chapter_01.commons;

public class ExamplesCollection {
    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
