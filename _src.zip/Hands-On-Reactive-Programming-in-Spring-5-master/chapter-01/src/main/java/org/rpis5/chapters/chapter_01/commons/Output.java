package org.rpis5.chapters.chapter_01.commons;

public class Output {
}
