package com.example.service.gitter.dto;

public enum Role {
    ADMIN,
    STANDARD
}
