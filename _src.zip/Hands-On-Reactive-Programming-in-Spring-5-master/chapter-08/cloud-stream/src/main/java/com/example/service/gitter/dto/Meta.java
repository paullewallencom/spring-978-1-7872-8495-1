package com.example.service.gitter.dto;

public class Meta {
}
