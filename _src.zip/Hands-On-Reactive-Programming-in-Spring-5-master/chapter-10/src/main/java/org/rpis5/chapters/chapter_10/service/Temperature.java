package org.rpis5.chapters.chapter_10.service;

import lombok.Value;

@Value
public class Temperature {
   private final double value;
}
