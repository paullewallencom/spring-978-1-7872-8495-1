package org.rpis5.chapters.chapter_02.observer;

public interface Observer<T> {
   void observe(T event);
}
