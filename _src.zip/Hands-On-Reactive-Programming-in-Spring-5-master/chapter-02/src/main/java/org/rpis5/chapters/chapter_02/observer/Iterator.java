package org.rpis5.chapters.chapter_02.observer;

public interface Iterator<T> {
   boolean hasNext();
   T next();
}
