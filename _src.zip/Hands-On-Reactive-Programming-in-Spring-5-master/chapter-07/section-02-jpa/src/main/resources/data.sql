insert into book values(10,'The Martian');
insert into book values(11,'Blue Mars');
insert into book values(12,'The Case for Mars');
insert into book values(13,'The War of Worlds');
insert into book values(14,'Edison''s Conquest of Mars');
insert into book values(15,'Moving Mars');
insert into book values(17,'Man Plus');
insert into book values(20,'A Martian Odyssey');
insert into book values(22,'The Martian Race');