create table book
(
   id integer auto_increment primary key,
   title varchar(255) not null,
   publishing_year integer not null,
);