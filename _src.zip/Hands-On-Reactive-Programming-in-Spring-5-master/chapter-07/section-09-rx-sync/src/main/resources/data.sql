insert into book values(12,'The Case for Mars', 1996);
insert into book values(14,'Edison''s Conquest of Mars', 1947);
insert into book values(15,'Moving Mars', 1993);
insert into book values(17,'Man Plus', 1976);
insert into book values(20,'A Martian Odyssey', 1934);
insert into book values(22,'The Martian Race', 1999);