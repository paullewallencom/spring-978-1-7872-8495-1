package org.rpis5.chapters.chapter_07.rx_dbs;

public class Chapter7ReactiveConnectorsApplication {
	public static void main(String[] args) {
		// This application is not intended to be executable
	}
}
