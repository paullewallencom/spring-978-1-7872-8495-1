package org.rpis5.chapters.chapter_07.rx_dbs;

public class User {
}
