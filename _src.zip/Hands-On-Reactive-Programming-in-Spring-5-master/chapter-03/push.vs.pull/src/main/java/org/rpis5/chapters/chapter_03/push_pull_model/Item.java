package org.rpis5.chapters.chapter_03.push_pull_model;

import lombok.Value;

@Value
public class Item {

	final String id;
}
