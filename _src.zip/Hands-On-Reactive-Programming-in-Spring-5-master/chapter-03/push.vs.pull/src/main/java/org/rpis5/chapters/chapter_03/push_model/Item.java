package org.rpis5.chapters.chapter_03.push_model;

import lombok.Value;

@Value
public class Item {

	final String id;
}
