package org.rpis5.chapters.chapter_06.sse;

public class StockItem {

    private String id;
    private String type;

    public String getId() {
        return id;
    }

    public String getType() {
        return type;
    }
}
