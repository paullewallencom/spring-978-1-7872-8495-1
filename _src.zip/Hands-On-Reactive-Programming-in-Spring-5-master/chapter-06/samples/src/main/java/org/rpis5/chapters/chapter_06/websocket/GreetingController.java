package org.rpis5.chapters.chapter_06.websocket;

import org.springframework.stereotype.Controller;

@Controller
public class GreetingController {

//    @MessageMapping("/hello")
//    @SendTo("/topic/greetings")
//    public Greeting greeting(HelloMessage message) {
//        return new Greeting("Hello, " + message.getName() + "!");
//    }

}



