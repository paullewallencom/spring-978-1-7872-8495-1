package org.rpis5.chapters.chapter_06.security;

public class Profile {

}
